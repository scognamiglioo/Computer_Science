import java.util.Scanner;

public class Exerc02 {
    public static void main(String[] args) {

        



}
}