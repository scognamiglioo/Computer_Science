class ponteiro1 {
    public static void main (String[] args){
    Hora h1 = new Hora(12, 30, 30);
    Hora h2 = new Hora(12, 30, 30);
    if (h1 == h2) 
    System.out.println("Identicos!");
    else
    System.out.println("Diferentes!");
    }
   }


   //EXIBE DIFERENTES POIS O STRING HORA PASSA A TER OUTRO VALOR 
   